package com.vpnswither

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import android.view.ViewGroup
import android.os.StrictMode
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var button: Button
    private var vpn = false
    private var selectedMac = "64:1c:b0:dc:78:a3"

    private val router = "http://192.168.1.1"
    private val tvs = mapOf(
        "Samsung — Юра" to "64:1c:b0:dc:78:a3",
        "Samsung — спальня" to "7c:0a:3f:d3:a7:c3"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        StrictMode.setThreadPolicy(StrictMode.ThreadPolicy.Builder().permitAll().build())

        val bg = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(32, 40, 32, 40)
            setBackgroundColor(Color.rgb(8, 36, 58))
        }

        val title = TextView(this).apply {
            text = "VPN Swither"
            textSize = 30f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        bg.addView(title, LinearLayout.LayoutParams(-1, -2))

        val device = Spinner(this)
        device.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, tvs.keys.toTypedArray())
        device.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: android.widget.AdapterView<*>?, v: android.view.View?, pos: Int, id: Long) {
                selectedMac = tvs.values.elementAt(pos)
                vpn = false
                updateUi()
            }
            override fun onNothingSelected(p: android.widget.AdapterView<*>?) {}
        }
        val sp = LinearLayout.LayoutParams(-1, 60)
        sp.setMargins(0, 45, 0, 15)
        bg.addView(device, sp)

        status = TextView(this).apply {
            text = "VPN отключен"
            textSize = 21f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        bg.addView(status, LinearLayout.LayoutParams(-1, 70))

        button = Button(this).apply {
            text = "ВКЛЮЧИТЬ VPN"
            textSize = 20f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(25, 118, 210))
            setOnClickListener { switchPolicy() }
        }
        val bp = LinearLayout.LayoutParams(500, 180)
        bp.setMargins(0, 20, 0, 0)
        bg.addView(button, bp)

        setContentView(bg)
    }

    private fun switchPolicy() {
        try {
            val login = getPreferences(0).getString("login", "admin") ?: "admin"
            val password = getPreferences(0).getString("password", "") ?: ""
            if (password.isEmpty()) {
                showCredentialsDialog()
                return
            }

            val policy = if (vpn) null else "VPN"
            val ok = setPolicy(login, password, selectedMac, policy)
            if (ok) {
                vpn = !vpn
                updateUi()
                Toast.makeText(this, "Политика изменена", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Keenetic не принял команду", Toast.LENGTH_LONG).show()
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Ошибка: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun showCredentialsDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 10, 40, 0) }
        val user = EditText(this).apply { hint = "Логин Keenetic"; setText("admin") }
        val pass = EditText(this).apply { hint = "Пароль Keenetic"; inputType = 0x81 }
        box.addView(user); box.addView(pass)
        AlertDialog.Builder(this).setTitle("Подключение к Keenetic")
            .setView(box).setPositiveButton("Сохранить") { _, _ ->
                getPreferences(0).edit().putString("login", user.text.toString()).putString("password", pass.text.toString()).apply()
            }.setNegativeButton("Отмена", null).show()
    }

    private fun md5(s: String) = hash("MD5", s)
    private fun sha256(s: String) = hash("SHA-256", s)
    private fun hash(alg: String, s: String): String =
        MessageDigest.getInstance(alg).digest(s.toByteArray()).joinToString("") { "%02x".format(it) }

    private fun setPolicy(login: String, password: String, mac: String, policy: String?): Boolean {
        val auth = URL("$router/auth").openConnection() as HttpURLConnection
        auth.requestMethod = "GET"
        auth.connect()
        val realm = auth.getHeaderField("X-NDM-Realm") ?: return false
        val challenge = auth.getHeaderField("X-NDM-Challenge") ?: return false
        val cookie = auth.getHeaderField("Set-Cookie")?.substringBefore(";") ?: return false
        val key = sha256(challenge + md5("$login:$realm:$password"))

        val a = URL("$router/auth").openConnection() as HttpURLConnection
        a.requestMethod = "POST"; a.doOutput = true
        a.setRequestProperty("Content-Type", "application/json")
        a.setRequestProperty("Cookie", cookie)
        a.outputStream.use { it.write(JSONObject().put("login", login).put("password", key).toString().toByteArray()) }
        if (a.responseCode !in 200..299) return false
        val session = a.getHeaderField("Set-Cookie")?.substringBefore(";") ?: cookie

        val body = JSONObject().put("mac", mac).put("permit", true)
        if (policy == null) body.put("policy", JSONObject().put("no", true)) else body.put("policy", policy)

        val w = URL("$router/rci/ip/hotspot/host").openConnection() as HttpURLConnection
        w.requestMethod = "POST"; w.doOutput = true
        w.setRequestProperty("Content-Type", "application/json")
        w.setRequestProperty("Cookie", session)
        w.outputStream.use { it.write(body.toString().toByteArray()) }
        return w.responseCode in 200..299
    }

    private fun updateUi() {
        status.text = if (vpn) "VPN включен" else "VPN отключен"
        button.text = if (vpn) "ВЫКЛЮЧИТЬ VPN" else "ВКЛЮЧИТЬ VPN"
    }
}
